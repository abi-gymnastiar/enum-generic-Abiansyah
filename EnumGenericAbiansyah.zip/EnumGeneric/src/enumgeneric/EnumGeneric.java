/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package enumgeneric;

/**
 *
 * @author OWNER
 */
public class EnumGeneric {

    public static void main(String[] args) {
        AccountType savings = AccountType.SAVINGS;
        Account acc1 = new Account("Abiansyah", 001, 15_000, savings);
        
        CellGeneric<Integer> cell = new CellGeneric<>();
        cell.setValue(acc1.accountNum);
        int y = (int) cell.getValue();
        
        GenericMethodClass gmc = new GenericMethodClass();
        
        String[] StringArr = {"Abiansyah", "Aldi Ikbal", "Joseph"};
        
        gmc.printArray(StringArr);
    }
    
}
