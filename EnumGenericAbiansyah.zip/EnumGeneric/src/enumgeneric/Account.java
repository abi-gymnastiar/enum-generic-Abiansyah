/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enumgeneric;

/**
 *
 * @author OWNER
 */
public class Account {
    private AccountType type;
    String accountName;
    int accountNum;
    int balance;
    
    Account(String name, int num, int amt, AccountType type)
    {
        this.accountName = name;
        this.accountNum = num;
        this.balance = amt;
        this.type = type;
    }
    
    public String toString()
    {
        return "\nAccount type  : " + this.type + super.toString();
    }
}
